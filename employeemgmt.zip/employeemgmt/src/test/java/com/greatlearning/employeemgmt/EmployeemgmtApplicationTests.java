package com.greatlearning.employeemgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
